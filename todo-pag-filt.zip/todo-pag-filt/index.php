
<?php
    include 'lib/task.php';
    $tasks = load_tasks(); // se foloseste return in structura data
?>

<?php 
    // prezentam, vivod
    include 'templates/task-list.php';
    include 'templates/task-form.php';
?>