<!-- // shablon, pentru lista de taskuri -->
<div>
    <h3>Showing tasks (<?php print count($tasks); ?>)</h3>
    <ul>
        <?php foreach($tasks as $task) { ?>
            <li>
                <input type="checkbox" <?php if($task["status"] == 'Done') { ?>checked<?php } ?>>
                <?php print $task['title']; ?>
                <small>
                    (<?php
                        print $task["created"]; 
                        // p/a: 1) history
                                // today, yesteday, this week, this month
                     ?>)
                </small>
            </li>
        <?php } ?>
    </ul>
</div>