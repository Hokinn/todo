<select >
    <option>Vasea</option>
    <option>Vikea</option>
</select>